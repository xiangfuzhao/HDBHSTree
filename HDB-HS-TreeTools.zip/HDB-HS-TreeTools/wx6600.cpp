#include "stdafx.h"
#include "wx6600.h"
#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <stdlib.h>
#include <windows.h>

bool setContains(ELEMENT * src, ELEMENT * dst, bool * swaped){
	ELEMENT * Qx56 = src;
	ELEMENT * QQ = dst;

	if (src[0] < dst[0]){
		Qx56 = dst;
		QQ = src;
		*swaped = true;
	}

	for (normalInt m=1; m<=QQ[0]; m++){
		bool r = false;
		for(normalInt n=1; n<=Qx56[0]; n++)
			if (QQ[m] == Qx56[n]){
				r = true;
				break;
			}
		if (r == false) return false;
	}

	return true;
}

bool delFromIndex(normalInt idx, normalInt * index){
	for (normalInt m=1; m<=index[0]; m++)
		if (index[m] == idx){
			for (normalInt n=m+1; n<=index[0]+1; n++)
				index[n-1] = index[n];
			index[0] = index[0]-1;
			return true;
		}

	return false;
}

int FillIndex(normalInt * index, ELEMENT (* dt)[ElementNumber]){
	index[0] = 0;
	index[1] = indexOver;
	normalInt x = 1;

	for (normalInt t=0; dt[t][0]>dataTableOver; t++){
		index[x] = t;
		x++;
	}

	index[0] = x-1;
	//carefule, -1 means border
	index[x] = indexOver;

	return 0;
}

int tableReducton(normalInt * index, ELEMENT (* dt)[ElementNumber]){
	normalInt m;
	normalInt subset = index[0];
	if (subset == 0) return -1;
	
	for (m=1; m<subset; m++ ){
		if (index[m] < 0) continue;
		
		for(normalInt n=m+1; n<subset+1; n++){
			if(index[n] < 0) continue;
			if(n == m) continue;

			ELEMENT* src = &dt[index[m]][0];
			ELEMENT* dst = &dt[index[n]][0];
			bool swaped = false;
			if (setContains( src, dst, &swaped)){
				int t = m;
				if (swaped) t = n;
				index[t] = -2; 
				index[0] = index[0]-1;
				if (swaped == false) break;			
			}
		}
	}

	normalInt idx[indexCount];//indexOver
	normalInt len=1;
	for (m=1; index[m]!=indexOver; m++)//m<=index[0]
		if (index[m] > -1){
			idx[len] = index[m];
			len++;
		}

	for (m=1; m<len; m++) index[m] = idx[m];
	index[len] = indexOver;

	return 0;
}

int resultTableReducton(normalInt * index, ELEMENT (* dt)[ElementNumber]){
	normalInt m;
	normalInt subset = index[0];
	if (subset == 0) return -1;
	
	for (m=1; m<subset; m++ ){
		if (index[m] < 0) continue;
		
		for(normalInt n=m+1; n<subset+1; n++){
			if(index[n] < 0) continue;
			if(n == m) continue;

			ELEMENT* src = &dt[index[m]][0];
			ELEMENT* dst = &dt[index[n]][0];
			bool swaped = false;
			if (setContains( src, dst, &swaped)){
				int t = m;
				if (swaped) t = n;
				index[t] = -2; 
				index[0] = index[0]-1;
				if (swaped == false) break;			
			}
		}
	}

	normalInt idx[resultIdxCount];//indexOver
	normalInt len=1;
	for (m=1; index[m]!=indexOver; m++)//m<=index[0]
		if (index[m] > -1){
			idx[len] = index[m];
			len++;
		}

	for (m=1; m<len; m++) index[m] = idx[m];
	index[len] = indexOver;

	return 0;
}

int prepareForRecursion(normalInt * index, ELEMENT (* dt)[ElementNumber]){
	normalInt t[indexCount];
	normalInt r = -1;
	normalInt m;
	
	if (index[0] == 0) return -1;
	
	//�˴����ڼ�¼����Ԫ�����ٵ������index��
	//ʾ��ԭʼ����{ {2 4 5} {1 2 3} {1 3 5} {2 4 6} {2 4} {2 3 5} {1 6} }
	//��Ӧindex��      0       1       2       3     4       5     6
	//����reduction�����õ�{ {1 2 3} {1 3 5} {2 4} {2 3 5} {1 6} }
	//��Ӧindex��               1       2     4     5       6
	//�˴����ս��t  2 | 4 6 ��Ҳ����4��6����Ϊ��ѡ��
	t[0] = 1;
	t[1] = index[1];
	for (m=2; m<=index[0]; m++){
		normalInt rowIdx = index[m];
		normalInt rowT = t[t[0]];
		
		if (dt[rowIdx][0] == dt[rowT][0]){
			t[0] = t[0]+1;
			t[t[0]] = index[m];
		}
		if (dt[rowIdx][0] < dt[rowT][0]){
			t[0] = 1;
			t[t[0]] = index[m];
		}
	}

	if (t[0] == 1){
		delFromIndex(t[1], index);
		return t[1];
	}

    //target��У� ��������������3��2����ôtarget[2] == 3
	if (t[0] > 1){
		normalInt target[MAX_target];
		memset(target, 0, MAX_target*sizeof(normalInt));
		for (m=1; m<=index[0]; m++)
			for (normalInt n=1; n<=dt[index[m]][0]; n++){
				normalInt t = dt[index[m]][n];
				//problem arise if (t > MAX_target-1),I just ignore this
				target[t] = target[t]+1;
			}

		//���ݰл�����������Ԫ�س���Ƶ��
		//t      0 | 4 6 ������
		//power  0 | 4 4 
		normalInt power[indexCount];
		memset(power, 0, indexCount*sizeof(normalInt));
		for (m=1; m<=t[0]; m++)
			for(normalInt n=1; n<=dt[t[m]][0]; n++){
				power[m] = power[m] + target[ dt[t[m]][n] ];
			}

		normalInt choice = -1;
		for (m=1; m<=t[0]; m++)
			if (power[m] > choice){
				choice = power[m];
				r = t[m];
			}
		
		delFromIndex(r, index);
		return r;
	}

	return r;
}

int elementContains(ELEMENT element, ELEMENT * row){
	bool r = false;
	
	for(normalInt m=1; m<=row[0]; m++)
		if (element == row[m])
			return true;

	return r;
}


bool makeNewIndex(ELEMENT element, normalInt * tempIndex, normalInt * index, ELEMENT (* dt)[ElementNumber]){
	tempIndex[0] = 0;

	if (index[0] == 0) return false;
	
	bool r = false;
	normalInt counter = 0;

	for(normalInt m=1; m<=index[0]; m++)
		if( elementContains(element, &dt[index[m]][0]) == false ){
			counter++;
			tempIndex[counter] = index[m];
			r = true;
		}
	tempIndex[counter+1] = indexOver;
	tempIndex[0] = counter;

	return r;
}

int buildTreeRecursion(Tree ** parent, 
					   normalInt * index, 
					   ELEMENT (* dt)[ElementNumber],
					   normalInt * node_num){
	if (index[0] == 0) return 0;

	int tR = tableReducton(index, dt);
	if (tR == -1) return -1;

	int selectedIdx = prepareForRecursion(index, dt);
	if (selectedIdx == -1) return -1;

	Tree * tree = (Tree *) malloc(sizeof(Tree));
	tree->nodeValue = -1;
	if (*parent == NULL){
		tree->parent = NULL;
		*parent = tree;
	}else{
		tree->parent = *parent;
		(*parent)->pointerCounter = 1;
		(*parent)->p[1] = tree;
	}
	
	ELEMENT *p = &(dt[selectedIdx][0]);
	normalInt counter = p[0];
	tree->pointerCounter = p[0];

	//there is a possible problem here,eg if counter > ElementNumber-1
	normalInt * tempIndex[indexCount];
	for (normalInt i=1; i<=counter; i++){
		Tree * son =  (Tree *) malloc(sizeof(Tree));
		son->nodeValue = p[i];
		son->parent = tree;
		son->pointerCounter = 0;
		tree->p[i] = son;
		tempIndex[i]= (normalInt *) malloc(indexCount * sizeof(normalInt) );
		makeNewIndex(p[i], tempIndex[i], index, dt);
		buildTreeRecursion(&son, tempIndex[i], dt, node_num);
		free(tempIndex[i]);

		(*node_num)++;
	}
	
	return 0;
}

int walkTree(Tree* tree, Tree** pool, normalInt * poolsize){
	Tree * p = tree;
	if (p == NULL) return -1;

	for (normalInt m=1; m<=p->pointerCounter; m++){
		if(p->p[m]->pointerCounter == 0){
			*poolsize = *poolsize+1;
			pool[*poolsize] = p->p[m];
		}
		if(p->p[m]->pointerCounter > 0){
			walkTree(p->p[m], pool, poolsize);
		}
	}

	return 0;
}

int outputHitSet(Tree * ball, ELEMENT * air){
	Tree * p = ball;

	while (p->parent != NULL){
		if (p->nodeValue != -1){
			air[0] = air[0]+1;
			air[air[0]] = p->nodeValue;
		}
		p = p->parent;
	}

	return 0;
}

int outputResults(Tree * tree, ELEMENT (* rt)[ElementNumber]){
	Tree * pool[MAX_Pool_Size];
	normalInt poolsize = 0;

	walkTree(tree, pool, &poolsize);

	normalInt counter = 0;
	for(normalInt m=1; m<=poolsize; m++){
		//problem arise if counter>ElementNumber-1
		rt[counter][0] = 0;
		outputHitSet( pool[m], &rt[counter][0] );
		counter++;
	}
	rt[counter][0] = dataTableOver;

	return 0;
}

int destroyTree(Tree * tree){
	if (tree == NULL) return 0;

	for(normalInt m=1; m<=tree->pointerCounter; m++) 
		destroyTree(tree->p[m]);
	
	free(tree);
	tree = NULL;

	return 0;
}
