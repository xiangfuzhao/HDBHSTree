// MyDlg1.cpp : implementation file
//

#include "stdafx.h"
#include "Interface008.h"
#include "MyDlg1.h"
#include "Interface008Dlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyDlg1 dialog


CMyDlg1::CMyDlg1(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDlg1::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDlg1)
	m_inedit = _T("{}");
	//}}AFX_DATA_INIT
	bitVec=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		bitVec[i]=0;
	}
}


void CMyDlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDlg1)
	DDX_Text(pDX, IDC_EDIT1, m_inedit);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyDlg1, CDialog)
	//{{AFX_MSG_MAP(CMyDlg1)
	ON_BN_CLICKED(IDC_B0, OnB0)
	ON_BN_CLICKED(IDC_B1, OnB1)
	ON_BN_CLICKED(IDC_B10, OnB10)
	ON_BN_CLICKED(IDC_B11, OnB11)
	ON_BN_CLICKED(IDC_B12, OnB12)
	ON_BN_CLICKED(IDC_B13, OnB13)
	ON_BN_CLICKED(IDC_B14, OnB14)
	ON_BN_CLICKED(IDC_B15, OnB15)
	ON_BN_CLICKED(IDC_B16, OnB16)
	ON_BN_CLICKED(IDC_B17, OnB17)
	ON_BN_CLICKED(IDC_B18, OnB18)
	ON_BN_CLICKED(IDC_B19, OnB19)
	ON_BN_CLICKED(IDC_B2, OnB2)
	ON_BN_CLICKED(IDC_B3, OnB3)
	ON_BN_CLICKED(IDC_B5, OnB5)
	ON_BN_CLICKED(IDC_B4, OnB4)
	ON_BN_CLICKED(IDC_B6, OnB6)
	ON_BN_CLICKED(IDC_B7, OnB7)
	ON_BN_CLICKED(IDC_B8, OnB8)
	ON_BN_CLICKED(IDC_B9, OnB9)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg1 message handlers

void CMyDlg1::OnB0() 
{
	bitVec[0]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB1() 
{
	bitVec[1]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}
void CMyDlg1::OnB10() 
{

	bitVec[10]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB11() 
{
	bitVec[11]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB12() 
{
	bitVec[12]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB13() 
{
	bitVec[13]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB14() 
{
	bitVec[14]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}
void CMyDlg1::OnB15() 
{
	bitVec[15]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB16() 
{
	bitVec[16]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB17() 
{
	bitVec[17]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB18() 
{
	bitVec[18]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB19() 
{
	bitVec[19]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB2() 
{
	bitVec[2]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB3() 
{
	bitVec[3]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB5() 
{
	bitVec[5]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB4() 
{
	bitVec[4]=1;
	m_inedit.Empty();
	m_inedit="{";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;	
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);
}

void CMyDlg1::OnB6() 
{
	bitVec[6]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB7() 
{
	bitVec[7]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB8() 
{
	bitVec[8]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnB9() 
{
	bitVec[9]=1;
	m_inedit.Empty();
	m_inedit="{";
	set_str.Empty();
	set_str="";
	CString s;
	for(int i=0;i<DefaultSize;i++)
	{
		if(bitVec[i])
		{
			s.Format("%d ",i);
			m_inedit+=s;
			set_str+=s;
		}
	}
	m_inedit+="}";
	UpdateData(FALSE);	
}

void CMyDlg1::OnOK() 
{
	// TODO: Add extra validation here
	//set_str=m_inedit;
	CDialog::OnOK();
}
