#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <afx.h>

#define MMAX 100	//the max number of all components
#define NMAX 100	//the max number of all conflict sets

//Classes definitions
//the definition of the class of Set
class CSSet
{
private:
	int * arr;
	int length;
	int MaxSize;
public:
	CSSet()  //���캯��
	{
		arr=(int *)malloc(sizeof(int));
		if(arr)
			arr[0]=0;
		length=0;
	}
	CSSet(int p[], int len)  //���캯��
	{
		arr=(int *)malloc(sizeof(int)*(len+1));
		if(arr)
		{
			for(int i=0;i<=len;i++)
				arr[i]=p[i];
		}
		length=len;
	}
	CSSet(char * str):MaxSize(20){   //���캯��
		assert(MaxSize>0);
		arr=new int[MaxSize];
		assert(arr!=0);
		for(int i=0;i<MaxSize;i++) arr[i]=0;
		int x;
		istrstream ss(str);                //������
		length=0;
		while(!ss.eof())                   //��������
		{
			length++;
			ss>>x;                         //ȡһ������
			assert(x>=0 && x<MaxSize);
			arr[length]=x;
		}
	}

	CSSet & CreateSet(int p[], int len)
	{
		if(this->arr)
		{
			//free(this->arr);
			this->arr=NULL;
		}
		this->arr=(int *)malloc((len+1)*sizeof(int));
		this->length=len;
		this->arr[0]=0;
		for (int i=1; i<=len; i++)
			this->arr[i]=p[i-1];

		return *this;
	}
	CSSet Add1(int elem)
	{
		int * p=(int *)malloc(sizeof(int)*(length+2));
		for (int i=0; i<=length; i++)
			p[i]=arr[i];
		p[length+1]=elem;
		CSSet set(p, length+1);
		return set;
	}
	CSSet Sub1(int elem)
	{
		int j=0,i;
		for(i=1;i<=length;i++)
			if(elem==arr[i])
			{
				j=i+1;
				break;
			}
		int * p=(int *)malloc(sizeof(int)*(length-i+1));
		int k=0;
		p[0]=arr[0];
		for (i=j; i<=length; i++)
			p[++k]=arr[i];

		CSSet set(p, k);
		return set;
	}
	int GetElemi(int i)
	{
		return arr[i];
	}

	CSSet& SubEpm(int elem)
	{
		int len=length;
		length=length-1;
		for(int i=1;i<=len;i++)
			if (GetElemi(i) == elem )
			{
				for(int j=i+1;j <= len; j++)
					arr[j-1]=arr[j];
				break;
			}
		return *this;
	}
	CSSet SubEpm2(int elem)
	{
		int * arrs = (int *)malloc(sizeof(int) * length);
		arrs[0] = 0;
		int i;
		for(i=1;i<=length;i++)
		{
			if (GetElemi(i) == elem )
				break;
			else
				arrs[i] = arr[i];
		}
		if (i<=length)
			for (int j= i+1; j<=length; j++)
				arrs[j-1] = arr[j];
		CSSet set(arrs, length-1);
		return set;
	}
	int * GetArr()
	{
		return arr;
	}
	int GetLen()
	{
		return length;
	}
	void disp()
	{
		for (int i=1;i<=length;i++)
			cout<<arr[i]<<" ";
	}
	BOOL Bn1SetContain(CSSet temp)
	{
		int i=length-1;
		int j=temp.GetLen();
		while (i>0)
		{
			while (arr[i]<temp.GetArr()[j])
				j--;
			if (j==0) return FALSE;
			if (arr[i]==temp.GetArr()[j])
			{
				i--;
				j--;
				continue;
			}
			else
				return FALSE;
		}
		return TRUE;
	}
	BOOL SetConatin(CSSet temp)
	{
		if(length >= temp.GetLen())
			return FALSE;

		int i=length;
		int j=temp.GetLen();
		while (i>0)
		{
			while (arr[i]<temp.GetArr()[j])
				j--;
			if (j==0) return FALSE;
			if (arr[i]==temp.GetArr()[j])
			{
				i--;
				j--;
				continue;
			}
			else
				return FALSE;
		}
		return TRUE;
	}
	BOOL einS(int e)
	{
		int i=length;
		while (e<arr[i])
			i--;
		if (e==arr[i])
			return TRUE;
		return FALSE;
	}
	BOOL einS2(int e)
	{
		for(int i=1;i<=length;i++)
			if(arr[i] == e)
				return TRUE;
		return FALSE;
	}

	CSSet & operator = (CSSet & temp)
	{
//		if (this->arr)
//			free(this->arr);
		this->arr = (int *)malloc(sizeof(int)*(temp.GetLen()+1));
		if(this->arr)
		{
			this->arr[0] = 0;
			for( int i=1; i<=temp.GetLen(); i++)
				this->arr[i]=temp.GetArr()[i];
		}
		this->length=temp.GetLen();
		return *this;
	}
	void SetFree()
	{
		if (arr)
		{
			free(arr);
			arr=NULL;
		}
	}

	int Rcount(int e, CSSet *F[], int n, int *flag)
	{
		int num=0;
		for(int i=0;i<n;i++)
			if(flag[i]==0 && F[i]->einS2(e))
			{
				num++;
				flag[i]=1;
			}
		return num;
	}

	~CSSet()
	{
//		if(arr)
//		{
//			free(arr);
//			arr=NULL;
//		}
	}
};

// the definition of the class of Node
class CSNode
{
private:
	int Epn;
	CSSet Sn;
	CSSet Ecn;
public:
	CSNode()
	{
		Epn=0;
	}

	int GetEpn()
	{
		return Epn;
	}
	CSSet GetSn()
	{
		return Sn;
	}
	CSSet& GetEcn()			//!!!!!This is a very important place: "&"!!!!!!!
	{
		return Ecn;
	}

	CSNode & operator = (CSNode & temp)
	{
		this->Epn=temp.Epn;
		this->Sn=temp.Sn;
		this->Ecn=temp.Ecn;
		return *this;
	}
	CSNode(int Epn1, CSSet Sn1, CSSet Ecn1)
	{
		Epn=Epn1;
		Sn=Sn1;
		Ecn=Ecn1;
	}
	~CSNode() {}
};

typedef struct LNode
{
	CSNode Data;
	struct LNode * next;
}LNode;

typedef struct iLNode
{
	CSNode Data;
	struct iLNode * next;
	int EcnCur;
}iLNode;

typedef struct iSELNode
{
	CSNode Data;
	struct iSELNode * next;
	int flag;
	struct iSELNode * parent;
}iSELNode;

typedef struct MSLNode 
{
	CSNode Data;
	struct MSLNode * next;
	int flag;
	struct MSLNode * parent;
	
	int EcnCur;	
	CSSet SMn;
}MSLNode;

