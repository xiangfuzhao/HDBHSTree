// Interface008Dlg.h : header file
//
#include "afxtempl.h"
#include "wx6600.h"

#if !defined(AFX_INTERFACE008DLG_H__0110823D_16DF_4998_8D79_A5DF84A9205F__INCLUDED_)
#define AFX_INTERFACE008DLG_H__0110823D_16DF_4998_8D79_A5DF84A9205F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CInterface008Dlg dialog

class CInterface008Dlg : public CDialog
{
// Construction
public:
	CInterface008Dlg(CWnd* pParent = NULL);	// standard constructor
    CList<CString,CString> m_strList;
// Dialog Data
	//{{AFX_DATA(CInterface008Dlg)
	enum { IDD = IDD_INTERFACE008_DIALOG };
	CListBox	m_jmhs_listbox;
	CListBox	m_bhsout2;
	CListBox	m_mscs_listbox;
	CListBox	m_csise_listbox;
	CListBox	m_ics_listbox;
	CListBox	m_csse_listbox;
	CListBox	m_hst_listbox;
	CListBox	m_hs_listbox;
	CListBox	m_chs_listbox;
	CListBox	m_esout;
	CListBox	m_bfout;
	CListBox	m_bhsout;
	CListBox	m_list;
	CString	m_bhstime;
	CString	m_bhsnum;
	CString	m_bfnum;
	CString	m_bftime;
	CString	m_estime;
	CString	m_esnum;
	CString	m_nodec1;
	int		m_chs_hitset;
	CString	m_chs_time;
	CString	m_hs_num;
	CString	m_hs_time;
	CString	m_hst_num;
	CString	m_hst_time;
	CString	m_csse_time;
	CString	m_csse_num;
	CString	m_ics_time;
	CString	m_ics_num;
	CString	m_csise_time;
	CString	m_csise_num;
	CString	m_mscs_num;
	CString	m_mscs_time;
	CString	m_ics_node;
	CString	m_csse_node;
	CString	m_csise_node;
	CString	m_mscs_node;
	CString	m_hs_node;
	CString	m_hst_node;
	CString	m_bhs_node;
	CString	m_chs_node;
	CString	m_bhstime2;
	CString	m_bhsnum2;
	CString	m_jmhs_time;
	CString	m_jmhs_num;
	//}}AFX_DATA
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CInterface008Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL
		
	public:
	//the first element in each one-dimensional array is reserved for array length
	//so is index[]
	ELEMENT dataTable[ElementNumber][ElementNumber];
	normalInt index[indexCount];
	Tree * tree;
	ELEMENT resultTable[resultIdxCount][ElementNumber];
	normalInt resultIdx[resultIdxCount];

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CInterface008Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnAdd();
	afx_msg void OnDel();
	afx_msg void OnBhsrun();
	afx_msg void OnAmend();
	afx_msg void OnBf();
	afx_msg void OnClearall();
	afx_msg void OnInput();
	afx_msg void OnEs();
	afx_msg void OnSe2();
	afx_msg void OnSeb();
	afx_msg void OnExit();
	afx_msg void OnAboutbox();
	afx_msg void OnButtonRand();
	afx_msg void OnSelchangeList1();
	afx_msg void OnSelchangeList2();
	afx_msg void OnChsCalculate();
	afx_msg void OnHsRun();
	afx_msg void OnHstRun();
	afx_msg void OnIcsRun();
	afx_msg void OnCsseRun();
	afx_msg void OnCsiseRun();
	afx_msg void OnMscsRun();
	afx_msg void OnAllRun();
	afx_msg void OnBhsrun2();
	afx_msg void OnJmhs();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_INTERFACE008DLG_H__0110823D_16DF_4998_8D79_A5DF84A9205F__INCLUDED_)
