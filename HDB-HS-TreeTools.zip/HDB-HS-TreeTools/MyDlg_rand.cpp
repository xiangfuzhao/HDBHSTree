// MyDlg_rand.cpp : implementation file
//

#include "stdafx.h"
#include "Interface008.h"
#include "MyDlg_rand.h"
#include "Interface008Dlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyDlg_rand dialog


CMyDlg_rand::CMyDlg_rand(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDlg_rand::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDlg_rand)
	m_inedit2 = _T("{}");
	//}}AFX_DATA_INIT
    bitVec=new int[DefaultSize];
	for(int i=0;i<DefaultSize;i++)
	{
		bitVec[i]=0;
	}
}


void CMyDlg_rand::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDlg_rand)
	DDX_Control(pDX, IDC_COMBO2, m_combo2);
	DDX_Text(pDX, IDC_EDIT1, m_inedit2);
	//}}AFX_DATA_MAP
}

BOOL CMyDlg_rand::OnInitDialog()
{
	CDialog::OnInitDialog();
	m_combo2.SetCurSel(0);
	CString s;
	for(int i=1;i<=DefaultSize;i++)
	{
        s.Format("%d",i);
		//m_combo2.AddString(s);
		m_combo2.InsertString(i,s);
	}
	return TRUE;
}

BEGIN_MESSAGE_MAP(CMyDlg_rand, CDialog)
	//{{AFX_MSG_MAP(CMyDlg_rand)
	ON_BN_CLICKED(IDC_CREATE, OnCreate)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg_rand message handlers

void CMyDlg_rand::OnCreate() 
{
	// TODO: Add your control notification handler code here
	int index=m_combo2.GetCurSel();
	CString s;
	s.Format("%d",index);
	int m;
	for(int i=0;i<DefaultSize;i++)
	{
		bitVec[i]=0;
	}
	if(index)                          //ָ�����ϴ�С
	{
		srand(GetTickCount());
		for(int i=0;i<index;i++)
		{
		    m=rand()%DefaultSize;
			while(bitVec[m%DefaultSize])
			{
				m++;
			}
			bitVec[m%DefaultSize]=1;
		}
	}
	else
	{
		srand(GetTickCount());
		index=rand()%DefaultSize;
		while(index==0)
		{
			index=rand()%DefaultSize;
		}
		for(int i=0;i<index;i++)
		{
		    m=rand()%DefaultSize;
			while(bitVec[m%DefaultSize])
			{
				m++;
			}
			bitVec[m%DefaultSize]=1;
		}
	}
	CString s0;
	CString s1;
	s0.Empty();
	for(int j=0;j<DefaultSize;j++)
	{
		if(bitVec[j])
		{
			s1.Format("%d ",j);
			s0+=s1;
		}
	}
	m_inedit2="{"+s0;
	m_inedit2+="}";
	set_str=s0;
	UpdateData(FALSE);	
	//MessageBox(s,s,MB_OK);
}

void CMyDlg_rand::OnAdd() 
{
	// TODO: Add your control notification handler code here
	CInterface008Dlg* p = (CInterface008Dlg*)this->GetParent();
	POSITION pos;
	 pos=p->m_strList.Find(set_str,NULL);
		if(set_str.IsEmpty())
		{
			MessageBox("���뼯�ϲ���Ϊ�ռ�","ע��",MB_OK);
		}
		else
 {
  if(pos==NULL)
  { 
   p->m_strList.AddHead(set_str);
      p->m_list.InsertString(0,m_inedit2);
  }
     else
  {
      MessageBox("�ü����Ѵ���","ע��",MB_OK);
  }
 }
}
