#if !defined(AFX_MYDLG1_H__273305A9_A292_4F19_840F_87B7E422F56F__INCLUDED_)
#define AFX_MYDLG1_H__273305A9_A292_4F19_840F_87B7E422F56F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyDlg1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyDlg1 dialog

class CMyDlg1 : public CDialog
{
// Construction
public:
	CMyDlg1(CWnd* pParent = NULL);   // standard constructor
    int* bitVec;
	CString set_str;
// Dialog Data
	//{{AFX_DATA(CMyDlg1)
	enum { IDD = IDD_DIALOG1 };
	CString	m_inedit;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyDlg1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyDlg1)
	afx_msg void OnB0();
	afx_msg void OnB1();
	afx_msg void OnB10();
	afx_msg void OnB11();
	afx_msg void OnB12();
	afx_msg void OnB13();
	afx_msg void OnB14();
	afx_msg void OnB15();
	afx_msg void OnB16();
	afx_msg void OnB17();
	afx_msg void OnB18();
	afx_msg void OnB19();
	afx_msg void OnB2();
	afx_msg void OnB3();
	afx_msg void OnB5();
	afx_msg void OnB4();
	afx_msg void OnB6();
	afx_msg void OnB7();
	afx_msg void OnB8();
	afx_msg void OnB9();
	afx_msg void OnAdd();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDLG1_H__273305A9_A292_4F19_840F_87B7E422F56F__INCLUDED_)
