#ifndef wx6600_h
#define wx6600_h

typedef int normalInt;
typedef char ELEMENT;

const normalInt ElementNumber = 32;
const normalInt indexCount = 32;
const normalInt resultIdxCount = 4096;
const normalInt MAX_target = 32;
const normalInt MAX_Pool_Size = 4096;
const normalInt indexOver = -1;

const ELEMENT dataTableOver = -1;

//tree strcture
const normalInt PointerNumber = 16;

typedef struct tagTree{
	ELEMENT nodeValue;
	normalInt pointerCounter;
	struct tagTree * parent;
	struct tagTree * p[PointerNumber];
}Tree;

//if src contains dst return true
//if dst contains src return true
//otherwise return false
bool setContains(ELEMENT * src, ELEMENT * dst, bool * swaped);
bool delFromIndex(normalInt idx, normalInt * index);

int FillIndex(normalInt * index, ELEMENT (* dt)[ElementNumber]);

//ȥ����
int tableReducton(normalInt * index, ELEMENT (* dt)[ElementNumber]);
int resultTableReducton(normalInt * index, ELEMENT (* dt)[ElementNumber]);

//return value: selected subset of original data
//return -1   : no more data
int prepareForRecursion(normalInt * index, ELEMENT (* dt)[ElementNumber]);
bool makeNewIndex(ELEMENT element, normalInt * tempIndex, normalInt * index, ELEMENT (* dt)[ElementNumber]);
int buildTreeRecursion(Tree ** parent, normalInt * index, ELEMENT (* dt)[ElementNumber], normalInt * node_num);

int walkTree(Tree* tree, Tree** pool, normalInt * poolsize);
int outputHitSet(Tree * ball, ELEMENT * air);
int outputResults(Tree * tree, ELEMENT (* rt)[ElementNumber]);

int destroyTree(Tree * tree);

#endif