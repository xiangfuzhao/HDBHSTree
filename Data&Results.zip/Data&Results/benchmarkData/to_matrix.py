import os
# 转换成矩阵格式，存放在FORMAT文件夹中
MATRIX_FORMAT_PATH = 'FORMAT'

# print(os.getcwd())
filenames = os.listdir('./')
output_filenames = []
# print(filenames)
def str_num(string):
    vec = string.split(' ')
    for i in range(len(vec)):
        vec[i] = int(vec[i])
    return vec
def str_num_cut(string):
    vec = string.split(' ')
    for i in range(len(vec)):
        vec[i] = int(vec[i])
    vec = vec[3:]
    return vec

for fname in filenames:
    if '.py' in fname or '.exe' in fname or 'time.txt' in fname:
        continue
    col_cnt = 0#the max column value in current file
    if os.path.isdir(fname):
        continue
    '''
    decide matrix transfer method
    '''

    with open(fname, 'r') as f:


        lines = f.readlines()
        # print(fname, f.readlines())
        line_cnt = 0# the lines count in current file
        data = []
        if 'LTree' in fname:
            first = False
            for l in lines:
                # l = l[0:-1]  # cut the \n
                if not first:
                    first = True
                    continue
                print(l, end='')
                l = l.strip()
                if not l.strip() == "":  # avoid empty line
                    line_cnt += 1
                    data.append(str_num_cut(l))
                    col_cnt = max(data[-1])
        else:
            for l in lines:
                #l = l[0:-1]  # cut the \n
                # print(l, end='')
                l = l.strip()
                if not l.strip() == "":  # avoid empty line
                    line_cnt += 1
                    data.append(str_num(l))
                    col_cnt = max(data[-1])
        # print("line cnt = ", line_cnt)
        # print("col_cnt = ", col_cnt)

    # write the matrix transformed
    if not os.path.exists(MATRIX_FORMAT_PATH):
        os.mkdir(MATRIX_FORMAT_PATH)
    output_filenames.append(fname[:-4]+"_Matrix.txt")
    file_matrix = open(MATRIX_FORMAT_PATH+"\\"+fname[:-4]+"_Matrix.txt", 'w')
    file_matrix.write(str(col_cnt)+' ')
    file_matrix.write(str(line_cnt)+'\n')
    for i in range(line_cnt):
        for j in range(col_cnt):
            if (j+1) in data[i]:
                file_matrix.write("1 ")
            else:
                file_matrix.write("0 ")
        file_matrix.write("x\n")
    file_matrix.close()

# 执行MHS2并记录时间
import subprocess
import time

# 设置程序运行的最大时间为1小时
with open('time.txt', 'w+') as f:
        f.write("")

MAX_RUNTIME = 5
for fname in output_filenames:
    print(f"正在执行{fname},",end='')
    start_time = time.time()

    process = subprocess.run(f"mhs2_without_output.exe -i {MATRIX_FORMAT_PATH}//{fname}")

    total_runtime = time.time() - start_time
    print(f"{fname}运行时间为: {total_runtime:.6f} 秒")

    with open('time.txt', 'a+') as f:
        f.write(f"{fname}运行时间为: {total_runtime:.6f} 秒\n")
