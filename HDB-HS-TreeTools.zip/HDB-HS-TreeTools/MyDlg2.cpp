// MyDlg2.cpp : implementation file
//

#include "stdafx.h"
#include "Interface008.h"
#include "MyDlg2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyDlg2 dialog


CMyDlg2::CMyDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CMyDlg2::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyDlg2)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CMyDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyDlg2)
	DDX_Control(pDX, IDC_LIST1, m_list1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMyDlg2, CDialog)
	//{{AFX_MSG_MAP(CMyDlg2)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyDlg2 message handlers

void CMyDlg2::OnBrowse() 
{
	CString FileName;
	CString s1;
	char * str1;
    CFileDialog dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY|OFN_OVERWRITEPROMPT,_T("Animation|*.txt|"));
	if(dlg.DoModal()==IDOK)
	{
		FileName=dlg.GetPathName();
		UpdateData(FALSE);
	}
	if(!FileName.IsEmpty())
	{
        str1=new TCHAR[FileName.GetLength()+1];
	    _tcscpy(str1, FileName); 
		CStdioFile file;
		file.Open(str1,CFile::modeRead|CFile::typeText);
		m_strList.RemoveAll();
		while(file.ReadString(s1))
		{
			m_strList.AddHead(s1);
			s1="{"+s1;
			s1+="}";
			m_list1.InsertString(0,s1);		
		}
		file.Close();
	}	
}
