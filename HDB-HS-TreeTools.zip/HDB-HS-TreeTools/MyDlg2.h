#if !defined(AFX_MYDLG2_H__C5D6901A_C14A_477F_A61F_911D3AF1DE1E__INCLUDED_)
#define AFX_MYDLG2_H__C5D6901A_C14A_477F_A61F_911D3AF1DE1E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyDlg2.h : header file
//
#include "afxtempl.h"
/////////////////////////////////////////////////////////////////////////////
// CMyDlg2 dialog

class CMyDlg2 : public CDialog
{
// Construction
public:
	CMyDlg2(CWnd* pParent = NULL);   // standard constructor
    CList<CString,CString> m_strList;
// Dialog Data
	//{{AFX_DATA(CMyDlg2)
	enum { IDD = IDD_DIALOG2 };
	CListBox	m_list1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyDlg2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMyDlg2)
	afx_msg void OnBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYDLG2_H__C5D6901A_C14A_477F_A61F_911D3AF1DE1E__INCLUDED_)
