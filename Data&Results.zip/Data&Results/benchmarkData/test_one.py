import time
import argparse
import subprocess

# 创建ArgumentParser对象
parser = argparse.ArgumentParser(description='Process some input.')

# 添加-i参数
parser.add_argument('-i', '--input', type=str, help='Input file name')

# 解析命令行参数
args = parser.parse_args()

# 判断是否传入了输入文件名
if args.input:
    input_file = args.input
    print(f"输入文件名为：{input_file}")
else:
    print("请传入输入文件名。")
    exit()

fname = input_file
print(f"正在执行{fname},",end='')
start_time = time.time()
process = subprocess.run(f"mhs2_without_output.exe -i {fname}")

total_runtime = time.time() - start_time
print(f"{fname}运行时间为: {total_runtime:.6f} 秒")

with open('time_long.txt', 'a+') as f:   
    f.write(f"{fname}运行时间为: {total_runtime:.6f} 秒\n")